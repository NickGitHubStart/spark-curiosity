param(
  [string]$Distro = "",
  [string]$LinuxRepoPath = "/home/nick/projects/spark-curiosity",
  [switch]$CopyToLocal = $true,
  [string]$LocalTarget = "",
  [switch]$NoOnboard,
  [switch]$UseDistBundle
)

$ErrorActionPreference = "Stop"

function Resolve-Distro {
  param([string]$Name)
  if ($Name) { return $Name }
  $list = & wsl.exe -l -q 2>$null
  if (-not $list) {
    throw "No WSL distro found. Install WSL first or pass -Distro."
  }
  return ($list | Where-Object { $_.Trim() } | Select-Object -First 1).Trim()
}

function To-UncPath {
  param([string]$DistroName, [string]$LinuxPath)
  $clean = $LinuxPath.Trim()
  if (-not $clean.StartsWith("/")) { $clean = "/$clean" }
  $winRel = $clean.TrimStart("/").Replace("/", "\")
  return "\\wsl$\$DistroName\$winRel"
}

# When run from \\wsl$\Distro\...\scripts\windows\install-from-wsl.ps1, derive distro and repo from path
# so we avoid WSL "test -d" (fails in some WSL/default-user contexts)
$fromWslUnc = $PSScriptRoot -like "\\wsl$\*"
if ($fromWslUnc -and (-not $Distro)) {
  $parts = $PSScriptRoot.TrimStart("\").Split("\")
  if ($parts.Length -ge 3 -and $parts[0] -eq "wsl$") {
    $distroName = $parts[1]
    $repoRootWin = $parts[2..($parts.Length - 3)] -join "\"   # strip \scripts\windows
    $repoUnc = "\\wsl$\$distroName\$repoRootWin"
    $LinuxRepoPath = "/" + ($repoRootWin.Replace("\", "/"))
  }
}

if (-not $repoUnc) {
  $distroName = Resolve-Distro -Name $Distro
  $repoUnc = To-UncPath -DistroName $distroName -LinuxPath $LinuxRepoPath
  # Optional: check repo exists via WSL (can fail depending on default user)
  $null = & wsl.exe -d $distroName -e test -d $LinuxRepoPath 2>$null
  if ($LASTEXITCODE -ne 0) {
    throw "WSL repo path not found: $LinuxRepoPath (distro: $distroName). Run this script from the repo (e.g. \\wsl$\Ubuntu\...\install-from-wsl.cmd) or pass -Distro and -LinuxRepoPath."
  }
}

if (-not $LocalTarget) {
  $LocalTarget = Join-Path $env:USERPROFILE "spark-curiosity"
}

if ($UseDistBundle) {
  Write-Host "[install-from-wsl] Dist-bundle mode: build in WSL, copy only bundle (dist + scripts), no full repo."
  $bundleDir = "$LinuxRepoPath/dist-windows-bundle"
  $zipName = "spark-curiosity-windows.zip"
  $zipLinux = "$bundleDir/$zipName"
  Write-Host "[install-from-wsl] Building bundle in WSL..."
  $null = & wsl.exe -d $distroName -e bash -c "cd '$($LinuxRepoPath -replace "'", "'\\''")' && bash scripts/create-windows-dist-bundle.sh '$($bundleDir -replace "'", "'\\''")'" 2>&1
  if ($LASTEXITCODE -ne 0) {
    throw "Bundle build failed in WSL. Check that scripts/create-windows-dist-bundle.sh exists and npm run build:desktop-stack succeeds."
  }
  New-Item -ItemType Directory -Path $LocalTarget -Force | Out-Null
  $wslTarget = "/mnt/" + $LocalTarget.Substring(0, 1).ToLower() + $LocalTarget.Substring(2).Replace("\", "/")
  Write-Host "[install-from-wsl] Copying bundle zip to $LocalTarget ..."
  $null = & wsl.exe -d $distroName -e cp "$zipLinux" "$wslTarget/"
  if ($LASTEXITCODE -ne 0) {
    throw "Copy of bundle zip from WSL failed."
  }
  $zipPath = Join-Path $LocalTarget $zipName
  if (-not (Test-Path $zipPath)) {
    throw "Zip not found after copy: $zipPath"
  }
  if (Test-Path (Join-Path $LocalTarget "spark-curiosity")) {
    Remove-Item (Join-Path $LocalTarget "spark-curiosity") -Recurse -Force
  }
  Expand-Archive -Path $zipPath -DestinationPath $LocalTarget -Force
  $targetRoot = Join-Path $LocalTarget "spark-curiosity"
  $runtimeInstaller = Join-Path $targetRoot "scripts\windows\install-runtime.ps1"
  if (-not (Test-Path $runtimeInstaller)) {
    $altInstaller = Join-Path $targetRoot "scripts\install-runtime.ps1"
    if (Test-Path $altInstaller) {
      $runtimeInstaller = $altInstaller
    } else {
      throw "Bundle missing install-runtime.ps1 at $runtimeInstaller"
    }
  }
  if ($NoOnboard) { $env:SPARK_NO_ONBOARD = "1" }
  Write-Host "[install-from-wsl] Running runtime installer (SkipBuild)..."
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $runtimeInstaller -SkipBuild
  return
}

$targetRoot = $repoUnc
if ($CopyToLocal) {
  Write-Host "[install-from-wsl] Copying repo from WSL to $LocalTarget ... (use -UseDistBundle for dist-only; -CopyToLocal:`$false to run from WSL path)"
  New-Item -ItemType Directory -Path $LocalTarget -Force | Out-Null
  $robocopyExclude = @(".git", "node_modules", "dist", ".turbo", ".next", ".cache", "coverage", ".cursor")
  robocopy $repoUnc $LocalTarget /E /XD $robocopyExclude /NFL /NDL /NJH /NJS /NP | Out-Null
  $targetRoot = $LocalTarget
}

$installer = Join-Path $targetRoot "install-local.ps1"
$installerExists = $false
if ($targetRoot -like "\\wsl\$*") {
  $installerLinuxPath = $LinuxRepoPath.TrimEnd("/") + "/install-local.ps1"
  $null = & wsl.exe -d $distroName -e test -f $installerLinuxPath 2>$null
  $installerExists = ($LASTEXITCODE -eq 0)
} else {
  $installerExists = Test-Path -LiteralPath $installer
}
if (-not $installerExists) {
  throw "Installer not found: $installer"
}

Write-Host "[install-from-wsl] Running installer: $installer"
$args = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $installer)
if ($NoOnboard) {
  $args += "-NoOnboard"
}
& powershell.exe @args
